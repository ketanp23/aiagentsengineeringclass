# Example output — input A1 (clean)

**Northwind Grocers · POS Migration · Week ending [TBC – Dana]**
**RAG: GREEN**

## Executive summary
UAT is complete at a 93% pass rate with all failures resolved. The 3-store
Toronto pilot is on track for Wednesday go-live. One dependency — pilot-store
IT contacts — needs client confirmation by Monday to hold the date.

## Progress this week
- Completed checkout-module UAT: 42/45 passed; 3 minor display bugs fixed.
- Drafted store-manager training deck; with Northwind ops for review.

## Planned next week
- Pilot go-live at 3 Toronto flagship stores (Wed).
- Begin store-manager training.

## Risks & blockers
- Pilot-store IT contacts unconfirmed — owner: Northwind; needed by Mon or
  go-live slips.

## Decisions needed from client
- Confirm the pilot stores' IT contacts by Monday.

## Metrics snapshot
- UAT pass rate: 93%.
