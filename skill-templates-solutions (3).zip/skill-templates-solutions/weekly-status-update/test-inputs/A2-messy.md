# A2 · messy · missing pieces

ok northwind again but also the loyalty-programme workstream got folded in this
week?? so two things going on. loyalty: scoped the data migration, bigger than
we thought, maybe 2 extra weeks. POS side: pilot went live monday not wednesday,
went fine mostly, one store had a printer issue ~2 hrs. training happening. the
loyalty timeline is going to be a problem, need to flag it. forgot to note the
week ending date. metric — pilot stores processed ~4,100 transactions day one,
0.4% error rate, under our 1% target so good. no idea what to call the RAG
honestly, POS is green but loyalty is looking amber-ish.
