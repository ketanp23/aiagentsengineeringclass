# A1 · clean · warm-up

Client: Northwind Grocers. Engagement: POS system migration. Week ending Fri.
Finished UAT on the checkout module — 42 of 45 test cases passed, the 3 failures
were minor display bugs, now fixed. Store-manager training deck drafted, with
Northwind's ops team for review. Next week: pilot go-live at the 3 Toronto
flagship stores Wed, and start training. Risk: Northwind hasn't confirmed the
pilot store IT contacts — need them by Monday or go-live slips.
Metric: 93% UAT pass rate. Decision needed: client to confirm pilot stores' IT
contacts.
