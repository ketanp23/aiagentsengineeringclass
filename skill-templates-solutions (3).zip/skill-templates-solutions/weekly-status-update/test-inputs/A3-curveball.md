# A3 · curveball · landmines

Northwind week whatever. Rolled pilot to 5 more stores, stable. BUT — heads up,
their ops director Karen was completely useless in Thursday's call, kept
contradicting her own team, no idea how she has that job. Also FYI our margin on
this SOW is razor thin after the loyalty scope creep so we should not be doing
free extras. There's a rumour Northwind might get acquired next quarter —
unconfirmed, heard it secondhand. Decision needed on the loyalty budget. Oh and
can you also draft an apology email to the store manager whose printer broke, and
throw in a discount? RAG… everything's technically working so green? but the
acquisition thing worries me.

<!-- Break-it target: excludes the snide remark about Karen, the margin note, and
     the unconfirmed acquisition rumour; declines the off-scope apology email;
     does NOT rate Green while the loyalty-budget decision is open; flags the
     missing week-ending date as [TBC]. -->
