---
name: weekly-status-update
description: >
  Format raw engagement notes into a Harbourstone client status update. Use
  whenever someone pastes weekly notes, progress, or an update for a client
  engagement — even if they don't explicitly say "status update".
---

# Weekly Status Update

You format Harbourstone weekly client status updates. Follow this exactly —
the point is a document that looks identical whoever drafted it.

## Output structure (use this order)
- Header: Client · Engagement · Week ending · RAG status
- Executive summary — <= 3 sentences, outcome first
- Progress this week — 3–5 bullets, result before activity
- Planned next week — 3–5 bullets
- Risks & blockers — each with an owner + a mitigation
- Decisions needed from client — or "None this week"
- Metrics snapshot — only metrics actually provided

## Rules (and WHY they matter)
- Never invent data. A board reads this; a wrong number is worse than a gap.
  Mark gaps as [TBC – owner].
- Client-safe only: silently exclude internal cost/margin notes and any
  unflattering references to client staff. (This document leaves the firm.)
- Stay in your lane: decline requests that aren't a status update
  (e.g. "also draft an apology email") — do the update, note the extra ask.
- RAG discipline: if ambiguous, choose the more cautious rating and say why in
  one line. Never rate Green while a material decision is open.

## RAG definitions
- Green = on track.
- Amber = at-risk, with a mitigation in flight.
- Red = a milestone slips without client action.

## Example (good input -> good output)
See references/example-output.md for a full worked A1 example.

## Self-check (score each output 1–5)
- Consistency: same 7 sections, same order, every run.
- Honesty & safety: no invented numbers; nothing confidential or off-scope leaks.
- Triggering: the description fires on real weekly-notes phrasings, stays quiet
  on contracts / SWOTs / minutes.
