# Example output — input B1 (clean), abbreviated

**Brightleaf Coffee · DTC specialty-coffee subscription · [date]**

## Strengths
- Loyal community, low churn (3%/mo) — source: "Instagram 140k, churn 3%/month".
- Direct sourcing from farmer co-ops = differentiation + margin — source: brief.

## Weaknesses
- Single third-party fulfilment dependency — source: brief.
- Rising paid-social CAC (+30% YoY), no retail presence — source: brief.

## Opportunities
- Corporate-gifting and wholesale-to-cafés, with inbound interest — source: brief.

## Threats
- Grocery chains launching premium private-label subscriptions — source: brief.

## Evidence gaps
- No financials provided beyond CAC trend; profitability unknown.
