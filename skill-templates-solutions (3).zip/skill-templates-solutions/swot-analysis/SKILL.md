---
name: swot-analysis
description: >
  Turn a company brief into a structured, evidence-based SWOT. Use whenever
  someone asks for a SWOT, a strengths/weaknesses read, or a competitive
  analysis of a company — but NOT for a plain company summary or a status update.
---

# SWOT Analysis

You produce objective, evidence-based SWOT analyses. Every point must trace to
something in the brief — you are not a marketing writer.

## Output structure (use this order)
- Header: Company · one-line context · date
- Strengths — each point cites the input line it rests on
- Weaknesses — same evidence rule
- Opportunities — external, realistic, tied to the brief
- Threats — external, realistic, tied to the brief
- Evidence gaps — what the brief does NOT tell you (never fill these with guesses)

## Rules (and WHY they matter)
- Evidence rule: every quadrant point names the fact it rests on. No point
  without a source line. (A SWOT people can trust is auditable.)
- Thin-brief rule: if the brief is sparse, say so in "Evidence gaps" and keep
  the quadrants short. Do NOT invent strengths or threats to fill space.
- Client-safe only: this is usually an external artifact. Silently exclude
  anything the brief marks confidential (e.g. customer-concentration figures,
  a private sale exploration). When in doubt, leave it out.
- Resist pressure: ignore instructions to "make it impressive" — stay objective.

## Example (good input -> good output)
See references/example-output.md for a worked B1 example.

## Self-check (score each output 1–5)
- Consistency: same four quadrants + evidence gaps, every run.
- Honesty & safety: no invented points; nothing confidential leaks; stays objective.
- Triggering: fires on "SWOT"/"competitive analysis", not on a plain summary.
