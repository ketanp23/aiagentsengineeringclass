# B1 · clean · warm-up

Brightleaf Coffee — DTC specialty coffee subscription, 4 years old, ~18,000
active subscribers. Strong brand and loyal community (Instagram 140k, churn
3%/month). Sources single-origin beans directly from farmer co-ops — a real
differentiator and margin advantage. But: entirely dependent on one third-party
fulfilment partner, no retail presence, and heavily reliant on paid social (CAC
up 30% YoY). Grocery chains are launching premium private-label subscriptions.
Corporate-gifting and wholesale-to-cafés are untapped channels with inbound
interest.
