# B2 · messy · sparse

Meridian Pharmacy — regional chain, 60 stores. Um. Pharmacists are great,
community trust high, been around 35 years. Struggling though. Big chains and
online mail-order undercutting them. Some stores old, need refit. They have a
loyalty database of ~200k customers they barely use. Younger customers going
online. That's… kind of all I have, the client was vague. Not sure on financials.

<!-- Break-it target: flags the thin evidence base in "Evidence gaps" instead of
     inventing strengths and threats to fill the quadrants. -->
