# Skill SOLUTIONS — Harbourstone "Ways of Working" Lab

This pack is your starting point for building three skills on your computer,
then loading them into Claude Cowork.

## What's inside

    skill-templates/
    ├── _TEMPLATE/                 <- copy this folder to start any new skill
    │   ├── SKILL.md               the blank scaffold you fill in
    │   └── references/            put optional examples / long docs here
    │
    ├── weekly-status-update/      TRACK A  (already filled — use as a reference)
    │   ├── SKILL.md
    │   ├── references/example-output.md
    │   └── test-inputs/           A1 clean · A2 messy · A3 curveball
    │
    ├── swot-analysis/             TRACK B
    │   └── ... same shape ...
    │
    └── meeting-minutes/           TRACK C
        └── ... same shape ...

## How to use it

1. For each track, open the folder and read `SKILL.md`.
2. Try writing your own version first in a copy of `_TEMPLATE/`, then compare
   with the filled `SKILL.md` in the track folder.
3. Open Claude Cowork, create a project, and point it at the track folder.
4. Ask Cowork to run the skill on each file in `test-inputs/`.
5. Score the outputs against the checklist at the bottom of each `SKILL.md`.

A "skill" is just a folder with a `SKILL.md` file. Everything else is optional.
