# references/

Optional. Put long examples, style guides, or lookup tables here.
Claude loads a file from this folder ONLY when the SKILL.md points to it and
the task needs it — that keeps the always-loaded part small.
