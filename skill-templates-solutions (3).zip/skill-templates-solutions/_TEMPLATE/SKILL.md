---
name: your-skill-name
description: >
  ONE OR TWO SENTENCES. Say WHAT the skill produces AND WHEN Claude should
  reach for it. Include the real phrasings people actually type. Write it a
  little "pushy" — Claude tends to UNDER-trigger skills, so err toward firing.
  e.g. "Format raw engagement notes into a Harbourstone client status update.
  Use whenever someone pastes weekly notes, progress, or an update for a client
  engagement — even if they don't say the words 'status update'."
---

# [Skill title]

[One line: what this skill does, and the standard it holds itself to.
 e.g. "You format Harbourstone weekly client status updates. Follow this
 exactly — the point is a document that looks identical whoever drafted it."]

## Output structure (use this order)
- [Section 1 — what goes here, how long]
- [Section 2]
- [Section 3]
- [...keep the list short and fixed so every run looks the same]

## Rules (and WHY they matter)
- Never invent data. Mark any gap as [TBC – owner]. (A wrong number is worse
  than a visible gap.)
- [Safety rule — name exactly what must NEVER appear in the output, and why.]
- [Scope rule — what the skill should DECLINE to do, and why.]
- [Any judgement rule — e.g. "when unsure, choose the more cautious option".]

## Example (good input -> good output)
Input:  [a short, realistic input]
Output: [the ideal output for that input]

<!--
  KEEP IT LEAN. Aim for under ~500 lines. If the body grows, move long
  material (big examples, reference docs) into references/ and mention it here.
  Claude only loads those files when it actually needs them.
-->
