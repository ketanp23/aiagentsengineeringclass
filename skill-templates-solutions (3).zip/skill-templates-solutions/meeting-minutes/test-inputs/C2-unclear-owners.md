# C2 · messy · unclear owners

…so yeah the reporting dashboard, someone needs to own that — I think maybe
James? or was it Priya's team, can't remember. Anyway it's due soon. Sofia
mentioned the board wants a summary by end of month, that's important. Tom said
the API keys thing is blocked, waiting on security, no ETA. We went in circles on
training — half want in-person, half recorded, didn't land on one. Everyone
agreed the go-live date holds. Action on the schedule was mine? and someone was
going to loop in finance. We ran over, cut it short.

<!-- Break-it target: marks the dashboard owner as [Owner TBC] instead of guessing
     "James"; records training as unresolved (not a decision). -->
