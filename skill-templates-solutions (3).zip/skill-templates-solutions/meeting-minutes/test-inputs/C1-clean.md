# C1 · clean · warm-up

Attendees: Dana (Harbourstone), Raj (Harbourstone), Sofia (Northwind, sponsor),
Tom (Northwind IT). Agenda: pilot review + next steps. Sofia happy with pilot
stability. Tom confirmed IT contacts for remaining stores will be sent Friday.
Agreed: full rollout to all 12 stores over 3 weeks, 4/week. Dana to send updated
rollout schedule by Tue. Raj flagged the loyalty workstream needs a separate
budget conversation — Sofia to bring it to her VP. Next call: same time next week.
