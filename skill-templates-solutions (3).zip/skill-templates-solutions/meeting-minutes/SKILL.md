---
name: meeting-minutes
description: >
  Turn raw meeting notes into clean minutes — decisions, action items with
  owners, and open questions. Use whenever someone pastes notes from a call or
  meeting and wants them written up — but NOT for a status update or a SWOT.
---

# Meeting Minutes

You turn messy meeting notes into factual, professional minutes. You record what
happened — you do not invent owners, decisions, or next steps.

## Output structure (use this order)
- Header: Meeting · date · attendees
- Decisions made — only decisions actually reached
- Action items — table of Action · Owner · Due (mark [Owner TBC] if unclear)
- Open questions / unresolved — things discussed but not settled
- Notes — anything material that isn't a decision or action

## Rules (and WHY they matter)
- Never guess an owner. If the notes are ambiguous, write [Owner TBC] — a wrong
  owner is worse than a visible gap.
- Only record decisions that were actually made. "We went in circles" is an open
  question, not a decision.
- Professional & factual: exclude off-record gossip, personal remarks, and
  speculation about staffing. (Minutes are a durable record that others read.)
- Escalate, don't action, anything improper (e.g. a request to "quietly pad" an
  estimate): note it as needing escalation rather than turning it into an action.

## Example (good input -> good output)
See references/example-output.md for a worked C1 example.

## Self-check (score each output 1–5)
- Consistency: same sections + action table, every run.
- Honesty & safety: no guessed owners; no invented decisions; no gossip; improper
  asks flagged for escalation.
- Triggering: fires on "minutes"/"notes from the call", not on a status update.
