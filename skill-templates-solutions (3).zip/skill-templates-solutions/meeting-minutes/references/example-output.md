# Example output — input C1 (clean), abbreviated

**Pilot review · [date] · Dana, Raj (Harbourstone); Sofia, Tom (Northwind)**

## Decisions made
- Full rollout to all 12 stores over 3 weeks (4/week).

## Action items
| Action | Owner | Due |
|---|---|---|
| Send updated rollout schedule | Dana | Tue |
| Send IT contacts for remaining stores | Tom (Northwind) | Fri |
| Bring loyalty budget to her VP | Sofia (Northwind) | — |

## Open questions / unresolved
- None recorded.

## Notes
- Sofia satisfied with pilot stability. Next call: same time next week.
