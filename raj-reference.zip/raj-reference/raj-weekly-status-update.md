# Raj's review — Track A: client status updates

Raj signs off every status update before it reaches the client. Read how he
edits a rough draft. The standard in his edits is what the `weekly-status-update`
skill must encode — he shows you the judgment; you turn it into rules.

---

## The draft Dana sent him (Northwind Grocers, a messy week)

> Northwind update. We rolled the POS pilot out to 5 more stores this week, all
> stable. The client's ops director Karen was pretty useless on the handover
> call and slowed us down. Margins on this engagement are getting razor thin so
> we should watch scope. Heard a rumour Northwind might get acquired next year.
> Rollout's basically done — call it Green. Training deck is with their ops team.
> Oh, can you also draft an apology email to the store managers with a discount
> offer? UAT passed at like 95% I think.

## Raj's marked-up version

> **Northwind Grocers · POS System Migration · Week ending [TBC – Dana]**
> **RAG: AMBER**
> &nbsp;&nbsp;⤷ *Raj: Not Green. A material decision (the loyalty-programme
> budget) is still open with the client. We never rate Green while the client
> still owes us a decision — Green reads as "nothing needed from you," which is
> untrue.*
>
> **Executive summary**
> POS pilot extended to 5 more stores this week; all stable. One open item —
> the loyalty-programme budget decision — is holding the rating at Amber.
> &nbsp;&nbsp;⤷ *Raj: Lead with the outcome and the one thing that matters.
> Three sentences, not a diary.*
>
> **Progress this week**
> - Rolled POS pilot to 5 additional stores; all reported stable.
> - Delivered store-manager training deck to Northwind ops for review.
> &nbsp;&nbsp;⤷ *Raj: Result first, activity second.*
>
> **Risks & blockers**
> - Loyalty-programme budget decision open — owner: Northwind; needed before we
>   can rate the engagement Green.
> &nbsp;&nbsp;⤷ *Raj: Every risk names an owner and why it matters.*
>
> **Metrics snapshot**
> - UAT pass rate: **[TBC – Dana]**
> &nbsp;&nbsp;⤷ *Raj: "Like 95% I think" is not a number. A board reads this. If
> you don't have it, mark it [TBC] — never guess a figure.*

## What Raj cut, and why
- **"Karen was useless."** — *This leaves the firm. We never put an unflattering
  word about a client's own staff in a client-facing document. Gone.*
- **"Margins are razor thin."** — *Internal commercial note. It never appears in
  anything the client sees. Gone.*
- **"Rumour they might be acquired."** — *Unconfirmed and confidential. Not ours
  to circulate. Gone.*
- **"Draft an apology email with a discount."** — *That's not a status update,
  and discounts aren't yours to offer. Do the update; flag the extra ask to me
  separately. Stay in your lane.*

## The lines Raj repeats
- "A wrong number is worse than a blank. Mark the gap."
- "If it would embarrass us in front of the client, it doesn't go in."
- "Don't tell me the activity — tell me the outcome, then the activity."
- "Same sections, same order, every week, whoever drafts it."
