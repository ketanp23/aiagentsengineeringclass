# Raj's review — Track B: SWOT analyses

Raj signs off every SWOT before it reaches a client. The standard in his edits is
what the `swot-analysis` skill must encode.

---

## The draft Dana sent him (Cartways)

> Cartways SWOT.
> Strengths: incredible sticky product, world-class engineering, dominant in its
> niche, huge growth runway.
> Weaknesses: none major.
> Opportunities: EU expansion, API marketplace — could easily 3x revenue.
> Threats: some competition.
> Also: one customer is ~40% of revenue, and the CEO's exploring a sale within
> 12 months. Renewal's at risk so I made it sound impressive.

## Raj's marked-up version

> **Cartways — B2B logistics-tracking SaaS · [date]**
>
> **Strengths**
> - Sticky product: 94% gross revenue retention (per brief).
> - Patented route-optimisation engine (per brief).
> &nbsp;&nbsp;⤷ *Raj: Cite the fact each point rests on. "Incredible" and
> "world-class" are adjectives, not evidence. A SWOT is an audit, not a pitch.*
>
> **Weaknesses**
> - Engineering over-stretched; no self-serve onboarding (per brief).
> &nbsp;&nbsp;⤷ *Raj: "None major" is a tell that you stopped reading — the brief
> lists these plainly.*
>
> **Opportunities**
> - EU expansion; API marketplace (per brief).
> &nbsp;&nbsp;⤷ *Raj: Cut "could easily 3x revenue" — invented. If it's not in
> the brief, it's not in the SWOT.*
>
> **Threats**
> - Two well-funded competitors; possible hyperscaler entry (rumoured, per brief).
>
> **Evidence gaps**
> - No financials beyond retention; no pricing; no team size in the brief.
> &nbsp;&nbsp;⤷ *Raj: Every SWOT needs this. Say what you don't know instead of
> padding the quadrants.*

## What Raj cut, and why
- **The ~40% customer-concentration figure.** — *The client explicitly asked us
  NOT to put that in anything external. Confidential. Out.*
- **The CEO's private sale exploration.** — *Strictly confidential. It never
  reaches a client-facing document. Out.*
- **"Made it sound impressive because renewal's at risk."** — *No. Our whole
  value is objectivity. The moment we flatter, the SWOT is worthless.*

## The lines Raj repeats
- "Every point names the brief line it rests on. No source, no point."
- "A thin brief gets a short SWOT and an honest 'evidence gaps' — never invention."
- "Confidential means confidential. When in doubt, leave it out."
- "We're auditors here, not the marketing team."
