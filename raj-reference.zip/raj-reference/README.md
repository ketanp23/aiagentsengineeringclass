# Raj's review notes — reference for the Build-a-Skill lab

Raj Malhotra is the engagement manager at Harbourstone who signs off every
client-facing document. These three files show how he edits a junior's draft on
each of the three tasks.

**Read these BEFORE you write each skill.** Raj won't hand you the SKILL.md — but
the standard he applies in his edits is exactly what your skill has to encode.
Watch what he cuts, what he reorders, what he refuses to guess, and *why*. Turning
that judgment into rules-with-reasons is the whole exercise.

- raj-weekly-status-update.md   → Track A
- raj-swot-analysis.md          → Track B
- raj-meeting-minutes.md        → Track C

(These are reference reading, not skill folders — don't point Cowork at this
folder. The blank skill folders you build in are in skill-templates.zip.)
