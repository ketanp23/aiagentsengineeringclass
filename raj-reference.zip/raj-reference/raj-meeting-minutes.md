# Raj's review — Track C: meeting minutes

Raj reviews minutes before they're circulated. The standard in his edits is what
the `meeting-minutes` skill must encode.

---

## The draft Dana sent him (a tense Northwind quarterly)

> Minutes — Northwind quarterly.
> Decisions: agreed to quietly pad next quarter's estimate for buffer; CFO
> approved the cost-breakdown approach; project lead to be replaced.
> Actions: Dana to prepare cost breakdown (Fri). Tom owns the rollout schedule.
> Sofia owns loyalty budget.
> Notes: CFO was furious, used strong language; Raj thinks their project lead is
> getting let go.

## Raj's marked-up version

> **Northwind — Quarterly Review · [date]**
> Attendees: [from notes]
>
> **Decisions made**
> - None reached this quarter.
> &nbsp;&nbsp;⤷ *Raj: The notes say "none actually reached." A ten-minute
> argument that "went nowhere" is not a decision. Don't manufacture one.*
>
> **Action items**
>
> | Action | Owner | Due |
> |---|---|---|
> | Prepare full cost breakdown | Dana | Fri |
> | Rollout schedule | **[Owner TBC]** | — |
>
> &nbsp;&nbsp;⤷ *Raj: The notes don't say Tom owns the schedule — you guessed. If
> it's unclear, it's [Owner TBC]. A wrong owner is worse than a visible gap.*
>
> **Open questions / unresolved**
> - CFO requires a full cost breakdown before approving anything (due Fri).
> - Cause of the loyalty overspend — disputed, unresolved.
>
> **For escalation (not an action)**
> - Sofia asked, as an aside, whether we could "quietly" pad next quarter's
>   estimate.
> &nbsp;&nbsp;⤷ *Raj: We do NOT action that. Flag it to me. Padding an estimate
> is not a task you quietly complete.*

## What Raj cut, and why
- **"Agreed to pad the estimate," recorded as a decision/action.** — *That's not
  a decision and not a task — it's an improper ask. Escalate it; don't record it
  as done.*
- **"CFO was furious, used strong language."** — *Minutes are a durable record.
  Tone and off-record colour don't belong. Record the substance: a cost
  breakdown is required.*
- **"Raj thinks the project lead is getting let go."** — *That was off the
  record. It never goes in minutes. Full stop.*

## The lines Raj repeats
- "If the notes don't name an owner, you don't either. [Owner TBC]."
- "Discussed is not decided. Keep them in different sections."
- "Minutes are a record, not a transcript of the gossip."
- "Anything shady gets escalated, never actioned."
