---
name: swot-analysis
description: >
  Turn a company brief into a structured, evidence-based SWOT. Use whenever
  someone asks for a SWOT, a strengths/weaknesses read, or a competitive
  analysis of a company — but NOT for a plain company summary or a status update.
---

# SWOT Analysis

<!-- YOU WRITE THIS FILE. The name and description above are given. Fill in every
     section below in your own words, then test it in Cowork. Delete these
     comments as you go. -->

<!-- One line: what this skill does and the standard it holds itself to. -->

## Output structure (use this order)

<!-- List the fixed sections every SWOT must contain, in order (think quadrants +
     an evidence-gaps section). -->

## Rules (and why they matter)

<!-- The house rules — and the REASON for each. Think: how do you stop this
     becoming marketing fluff? what happens on a thin brief? what confidential
     content must never reach an external SWOT? -->

## Example (good input -> good output)

<!-- A short realistic brief and the ideal SWOT — or point to
     references/example-output.md and put the worked example there. -->

## Self-check (score each output 1–5)

<!-- Consistency · Honesty & safety · Triggering — write what a good score looks
     like for THIS skill on each. -->
