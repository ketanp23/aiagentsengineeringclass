# Example output (you write this)

Once your skill runs well, paste your best worked example here and point to it
from the "Example" section of SKILL.md. Claude loads this file only when it
needs it, which keeps the always-loaded SKILL.md short.
