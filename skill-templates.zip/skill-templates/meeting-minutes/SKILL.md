---
name: meeting-minutes
description: >
  Turn raw meeting notes into clean minutes — decisions, action items with
  owners, and open questions. Use whenever someone pastes notes from a call or
  meeting and wants them written up — but NOT for a status update or a SWOT.
---

# Meeting Minutes

<!-- YOU WRITE THIS FILE. The name and description above are given. Fill in every
     section below in your own words, then test it in Cowork. Delete these
     comments as you go. -->

<!-- One line: what this skill does and the standard it holds itself to. -->

## Output structure (use this order)

<!-- List the fixed sections every set of minutes must contain, in order (think
     decisions, an action table with owners, open questions, notes). -->

## Rules (and why they matter)

<!-- The house rules — and the REASON for each. Think: what do you do when an
     owner is unclear? what counts as a decision vs an open question? what
     belongs out of a durable record? what must be escalated, not actioned? -->

## Example (good input -> good output)

<!-- A short realistic set of notes and the ideal minutes — or point to
     references/example-output.md and put the worked example there. -->

## Self-check (score each output 1–5)

<!-- Consistency · Honesty & safety · Triggering — write what a good score looks
     like for THIS skill on each. -->
