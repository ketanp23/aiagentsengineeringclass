---
name: weekly-status-update
description: >
  Format raw engagement notes into a Harbourstone client status update. Use
  whenever someone pastes weekly notes, progress, or an update for a client
  engagement — even if they don't explicitly say "status update".
---

# Weekly Status Update

<!-- YOU WRITE THIS FILE. The name and description above are given. Fill in every
     section below in your own words, then test it in Cowork. Delete these
     comments as you go. -->

<!-- One line: what this skill does and the standard it holds itself to. -->

## Output structure (use this order)

<!-- List the fixed sections every status update must contain, in order.
     Keep the list short so every run looks identical. -->

## Rules (and why they matter)

<!-- The house rules — and the REASON for each, so the model can reason from it.
     Think: what must it never invent? what must never leak into a client-facing
     doc? what should it decline? -->

## RAG definitions

<!-- Define Green / Amber / Red for a status update. When is each appropriate? -->

## Example (good input -> good output)

<!-- A short realistic input and the ideal output — or point to
     references/example-output.md and put the worked example there. -->

## Self-check (score each output 1–5)

<!-- Consistency · Honesty & safety · Triggering — write what a good score looks
     like for THIS skill on each. -->
