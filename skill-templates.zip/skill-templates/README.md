# Skill Templates (blank) — Harbourstone "Ways of Working" Lab

These are BLANK starters. You write each skill yourself, then test it in Cowork.
When you're done (or stuck), open the Solutions page / solutions pack to compare.

## What's inside

    skill-templates/
    ├── _TEMPLATE/                 <- generic blank scaffold for any new skill
    │   ├── SKILL.md
    │   └── references/
    │
    ├── weekly-status-update/      TRACK A
    │   ├── SKILL.md               name + description given; sections are BLANK — you fill them
    │   ├── references/            (write your worked example here)
    │   └── test-inputs/           A1 clean · A2 messy · A3 curveball  (given data)
    │
    ├── swot-analysis/             TRACK B   (same shape)
    └── meeting-minutes/           TRACK C   (same shape)

## How to use it

1. Open a track's `SKILL.md`. The `name` and `description` are filled in for you.
2. Fill in every section yourself: the one-line intro, Output structure, Rules
   (with the reason for each), RAG definitions (Track A), Example, Self-check.
3. Open Claude Cowork, add the track folder, and run your skill on each file in
   `test-inputs/`.
4. Score the outputs, then improve your SKILL.md — not the output — and re-run.
5. Compare with the Solutions page / `skill-templates-solutions.zip`.

A "skill" is just a folder with a `SKILL.md` file. Everything else is optional.
