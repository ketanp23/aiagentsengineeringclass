---
name: insight-review
# HINT: This is the star of the session. Trigger it whenever someone has an AI output / big table
# / candidate results and asks "what does this mean", "what are the real takeaways", "which are
# meaningful", "what should we do", or wants signal separated from noise. Be pushy: tell Claude
# NOT to take the analysis at face value. Note it chains after campaign-vtr-analysis.
description: >-
  TODO — write the trigger description here.
---

# Insight Review — finding meaningful insights in AI output

<!-- HINT: One line on the core idea — an AI analysis is a starting point, not an answer. It will
     rank a 91%-VTR / 40-impression placement above a 68%-VTR / 200k one. Your job: keep what
     matters, bin the rest, with the numbers. -->
TODO

## The three tests
<!-- HINT: Every candidate insight must pass all three or it's noise. Name and define them:
     Material (enough volume — apply a volume floor), Reliable (not small-sample luck — a rate on
     a tiny denominator is a trap), Actionable (maps to a real decision). -->
TODO

## Workflow
<!-- HINT: 1) restate the goal in NUMBERS  2) set & apply a volume floor, report what it removed
     3) separate signal from noise — name the high-rate/low-volume traps you're excluding
     4) build a shortlist with a RUNNING cumulative total until the goal is met (no double-counting
     overlapping combos)  5) build a stop-list (high-volume, low-VTR)  6) audit the AI output for
     over-claims / things asserted without a number. -->
TODO

## Output format
<!-- HINT: A short "Meaningful Insights brief": Goal (in numbers) · the 3-5 insights that matter
     (each ending in its number) · shortlist running-total table · stop-list · "what we ignored
     and why" (the noise + any AI over-claims — this section is the whole point). -->
TODO

## Guardrails
<!-- HINT: Never a rate without its volume; never double-count overlapping segments; always state
     the volume floor. Prefer few high-confidence insights. Disagree with the AI where the data
     warrants — that's the job. -->
TODO
