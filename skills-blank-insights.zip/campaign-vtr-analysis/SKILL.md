---
name: campaign-vtr-analysis
# HINT: The description is the TRIGGER. Say WHAT it does (analyse ad campaign data, compute VTR
# across dimensions & combinations) and WHEN to fire — name phrases a user types: "analyze this
# campaign", "optimize VTR", "which placements work", impressions/completed views data. Be pushy.
description: >-
  TODO — write the trigger description here.
---

# Campaign VTR Analysis

<!-- HINT: One line on the job — map where VTR is high/low, always carrying volume alongside. -->
TODO

## Expected input
<!-- HINT: Which dimensions and metrics? (App/URL, Exchange, City, Environment, Player Size,
     Device Type; Impressions; Complete Views). Define VTR = Complete Views / Impressions and
     note it's a RATIO — only trustworthy when impressions are large. -->
TODO

## Workflow
<!-- HINT: Ordered steps with real computation. Think: 1) clean & report totals + overall VTR
     2) VTR per single dimension  3) scan 2-/3-/4-dimension combinations  4) tag each by volume
     5) list candidate winners AND candidate losers. Which steps run in PARALLEL as sub-agents? -->
TODO

## Output format
<!-- HINT: A table of candidate strategies — always impressions AND VTR together, plus a volume
     tag. Put the campaign's overall VTR + total impressions at the top as the baseline to beat. -->
TODO

## Deliverable
<!-- HINT: What file? (Excel workbook: Overview sheet + Combinations sheet). What to print at top? -->
TODO

## Guardrails
<!-- HINT: The non-negotiables — never a VTR without its impressions; don't pre-filter to "good"
     here (judgement happens later); never invent segments. -->
TODO
