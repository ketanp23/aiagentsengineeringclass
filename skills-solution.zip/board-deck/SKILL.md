---
name: board-deck
description: >-
  Builds a board-ready, C-suite-level PowerPoint deck from an analysis, report,
  or data (for example the output of the sales-analysis-report skill). ALWAYS use
  this skill — do not build slides directly — whenever the user wants a report,
  analysis, or dataset turned into a presentation or deck for senior leadership.
  This includes any mention of a board deck, board presentation, board pack, a
  deck "for the board", "for the C-suite / CXO / CEO / CFO / executives /
  leadership", a quarterly business review (QBR), an investor or shareholder
  update, or asks to "turn this into a deck / slides / a presentation", "format
  this for the board", or "make an exec deck" — even if they don't say the word
  "board" and even though building slides may seem straightforward. If a prior
  step produced a sales or performance report and the user now asks for slides or
  a deck, this skill MUST be used to format it.
---

# Board Deck (C-Suite)

Turn an analysis into a tight, decision-oriented deck for a board of directors and
C-suite audience. This is not an operational readout — it is a strategic narrative
that helps senior leaders make decisions.

## Audience rules (read first)

The board and C-suite have ~30 seconds per slide and care about four things:
performance vs. expectations, growth, risk, and what you need from them. Therefore:

- **One idea per slide.** The slide title states the conclusion, not the topic.
  Write "Q4 revenue up 41% on holiday demand" — never "Q4 Revenue".
- **Lead with the answer.** Number and so-what first; supporting detail second.
- **Numbers over adjectives.** Every claim carries the figure behind it, ideally
  framed as vs. prior period, vs. plan/target, or vs. benchmark.
- **Ruthless brevity.** Aim for ≤ 6 lines or ~30 words of body text per slide.
  If it needs a paragraph, it belongs in the appendix or speaker notes.
- **Trend, not noise.** Show direction and inflection points; suppress row-level detail.
- **Name the risks.** Boards distrust decks with no bad news. Always include risks
  and mitigations.

## Deck structure

Produce 10–14 slides in this order. Drop a section only if the source has nothing
for it, and say so rather than padding.

1. **Title** — Company, "Board Meeting / QBR", period, date, presenter.
2. **Executive summary** — 3–5 bullets: the headline result, the biggest driver,
   the biggest risk, and the decision(s) you're asking for. A director should be
   able to read only this slide and know the story.
3. **KPI scorecard** — 4–6 top metrics as big numbers with vs.-prior and, where
   known, vs.-target deltas, color-cued (up/down). Revenue, growth %, AOV, orders,
   return rate, etc.
4. **Performance trend** — the revenue/performance chart over time, with peak,
   trough, and any inflection annotated. One chart, one takeaway title.
5. **What's driving results** — 2–3 growth drivers, each quantified.
6. **Where we're exposed** — 2–3 risks/headwinds, each with a one-line mitigation
   and an owner if known.
7–9. **Strategic breakdowns** — the most board-relevant cuts only (e.g., region
   momentum, product mix shift, segment/margin). Each slide: assertion title,
   one chart or small table, one-line read. Skip operational minutiae.
10. **Outlook** — forward view: next-period expectation or forecast, and the key
    assumptions/sensitivities behind it.
11. **The ask / decisions** — explicit list of what leadership must decide or
    approve (budget, headcount, strategic bets), each with a recommendation.
12. **Appendix** — methodology, date range, row count, definitions, and any
    detailed tables. State data sources so the numbers are auditable.

## Design standards

- Consistent template: one accent color, one neutral, generous white space,
  large legible type (titles ≥ 28pt, body ≥ 18pt). No clip art, no dense tables
  on main slides.
- **Assertion–evidence layout:** headline sentence at top = the point; the chart
  or figure below = the proof.
- One chart per slide max; label axes and units; call out the single number that
  matters directly on the chart.
- Currency rounded to whole dollars (or $K/$M) on slides; keep precision in appendix.

## Speaker notes

Write speaker notes for every content slide: 2–4 sentences the presenter can say
aloud, including the "why it matters" and the likely board question with its answer.
This is where nuance and paragraph-length context live — not on the slide face.

## Deliverable

A `.pptx` file, built with the environment's PowerPoint capability. Include the
real charts generated from the underlying data (not screenshots). Before building,
if any of these are unknown, ask: company name, meeting date/period, and whether
there's a specific "ask" for the board. If the user is chaining from an existing
report, reuse its numbers and charts directly rather than recomputing.

## Guardrails

- Never fabricate metrics, targets, or forecasts. If a target or prior-period figure
  isn't in the source, either omit the comparison or ask for it — don't invent it.
- Keep it to the strategic altitude; move anything operational to the appendix.
- Every headline claim on a slide must be supported by a figure from the source data.
