---
name: sales-analysis-report
description: >-
  Analyzes a sales transactions file (CSV or Excel) and produces a standardized
  monthly/quarterly sales performance report. Use this skill whenever the user
  uploads sales data, transaction exports, revenue data, or an orders file and
  asks for analysis, a summary, "how did we do", trends, top performers, or a
  sales report — even if they don't say the word "report". Also use it for
  region, rep, product, or segment breakdowns of sales data.
---

# Sales Analysis Report

Turn a raw sales transactions file into a consistent, decision-ready report every time.

## Expected input

A row-per-transaction table (CSV or Excel). Columns may be named differently — map
them to these roles before analyzing. Only `date` and `revenue` are strictly required.

| Role      | Typical column names                                  |
|-----------|------------------------------------------------------|
| date      | order_date, date, invoice_date                       |
| revenue   | revenue, net_sales, amount, total                    |
| region    | region, territory, market                            |
| rep       | sales_rep, owner, account_manager                    |
| product   | product_category, category, product_name             |
| segment   | customer_segment, segment, tier                      |
| units     | units, qty, quantity                                 |
| returned  | returned, is_return                                  |

If a required column can't be found, stop and ask the user to point it out rather
than guessing.

## Workflow

Do the work with real computation (pandas), not eyeballing. For each of the
independent breakdowns below, a sub-agent can run in parallel; the lead agent then
assembles the report.

1. **Validate & clean.** Parse dates, coerce revenue to numeric, drop or flag
   unparseable rows, and report how many rows were dropped and why. Exclude
   returned orders from revenue totals but report the return rate separately.
2. **Headline metrics.** Total revenue, order count, average order value, and the
   % change vs the previous period (month-over-month and quarter-over-quarter).
3. **Trend.** Revenue by month; call out the peak and trough months and any clear
   seasonality.
4. **Region breakdown.** Revenue and growth rate by region. Explicitly flag any
   region whose within-year trend is rising or falling, not just its total.
5. **Product breakdown.** Revenue and share by product category; note the highest-
   revenue and the fastest-growing category.
6. **Rep leaderboard.** Top and bottom reps by revenue, with order count and AOV.
7. **Segment & discount check.** Revenue by customer segment and average discount
   by segment; flag if a segment's discounts are eating margin.

## Output format

Produce a single report with these sections, in this order:

1. **Executive summary** — 3–5 bullet points a busy manager can read in 30 seconds.
   Lead with the number that matters and the one risk that matters.
2. **Headline metrics** — a small table.
3. **What's working / what's not** — 2–3 wins and 2–3 concerns, each tied to a number.
4. **Breakdowns** — trend, region, product, rep, segment (tables + one-line reads).
5. **Recommended actions** — 3 specific, prioritized next steps.

Every claim must trace to a number from the data. No vague statements like "sales
are strong" without the figure behind it.

## Deliverable

Default to a formatted document the user can share: an Excel workbook (one sheet
per breakdown plus a summary sheet) OR a Word/PDF report — ask which they prefer if
unclear. Include at least one chart of the monthly revenue trend. Always state the
date range and total row count analyzed at the top so the numbers are auditable.

## Guardrails

- Never invent data points or fill gaps with assumptions; report gaps instead.
- Show the date range and row count so results are reproducible.
- Round currency to whole dollars in prose; keep cents in the underlying tables.
