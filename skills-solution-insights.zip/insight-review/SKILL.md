---
name: insight-review
description: >-
  Pressure-tests an AI analysis or model output and extracts only the MEANINGFUL insights —
  the ones material, reliable and actionable enough to base a decision on. ALWAYS use this —
  do not take an analysis at face value — whenever the user has an AI output, a big table of
  results, a data breakdown, or a set of "candidate strategies" and asks what it means, what
  the real takeaways are, which findings are meaningful, what to actually do, or wants signal
  separated from noise. Chains naturally after campaign-vtr-analysis (or any analysis skill).
---

# Insight Review — finding meaningful insights in AI output

An AI analysis is a *starting point, not an answer*. It will happily rank a 91%-VTR placement
that ran 40 impressions above a 68%-VTR placement that ran 200,000. Your job is to find the
findings that actually matter and throw the rest out — visibly, with the numbers.

## The three tests

Every candidate insight must pass all three, or it is noise:

- **Material** — is the volume big enough to move the goal? A great rate on tiny volume changes
  nothing. Apply a **volume floor** and say what it is.
- **Reliable** — is the signal real, or small-sample luck? A ratio (VTR, conversion rate) on a
  small denominator is untrustworthy. High rate + low volume = a trap, not a tactic.
- **Actionable** — does it map to a decision someone can take (scale it, cut it, shift budget)?
  An interesting fact that changes no action is trivia.

## Workflow

1. **Restate the goal in numbers.** Write the target explicitly before judging anything
   (e.g. "assemble strategies that together deliver ≥ 2,450,000 impressions at ≥ 62% VTR",
   against a current blended VTR you state).
2. **Set and apply a volume floor.** Choose a minimum impressions threshold and drop everything
   below it *before* ranking. Report how many candidates that removed. This is the single most
   important move — it kills the small-sample traps.
3. **Separate signal from noise.** From what survives, name the genuinely meaningful patterns.
   Explicitly call out the seductive high-rate / low-volume combos you are excluding and why.
4. **Build the shortlist.** Assemble the winning strategies into a list that *cumulatively*
   clears the target. Show a running total: Strategy · Impressions · VTR · cumulative impressions
   · blended VTR so far. Stop when the target is met. Do not let overlapping combinations
   double-count the same impressions.
5. **Build the stop-list.** The high-volume, low-VTR segments dragging the average down — what to
   pause or exclude, with the impressions they'd free up.
6. **Audit the AI output.** List anything the analysis over-claimed, double-counted, or asserted
   without a number. If a claim can't be traced to impressions + VTR, flag it.

## Output format

A short **Meaningful Insights brief**:

1. **Goal** — the target in numbers, and the current baseline.
2. **The 3–5 insights that matter** — each one sentence, each ending in the number that proves it.
3. **Shortlist to hit the goal** — the running-total table; state the final cumulative impressions
   and blended VTR so the reader can see the target is cleared.
4. **Stop-list** — what to cut and the volume it frees.
5. **What we ignored, and why** — the noise: the tiny high-VTR traps and any over-claims from the
   AI output. This section is the point of the exercise — show your discipline.

## Guardrails

- Never present a rate without the volume behind it. Never let cumulative claims double-count
  overlapping segments. Always state the volume floor you used.
- Prefer fewer, higher-confidence insights over a long list. If something can't be tied to a
  number, it doesn't go in the brief.
- Disagree with the AI output where the data warrants — that is the job, not a failure.
