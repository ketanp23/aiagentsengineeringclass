---
name: campaign-vtr-analysis
description: >-
  Analyzes programmatic / video advertising campaign data (impressions, completed views)
  and computes View-Through-Rate (VTR) across every dimension and dimension-combination.
  Use whenever the user uploads campaign data, ad-server or exchange logs, impressions/views
  data, or asks to analyze, optimize, or break down a video campaign, VTR, completion rate,
  or "which placements are working" — even if they don't say "VTR". Produces the raw candidate
  strategies; pair it with the insight-review skill to turn them into decisions.
---

# Campaign VTR Analysis

Turn raw campaign logs into a complete, honest map of where View-Through-Rate is high or low —
always carrying the volume alongside the rate.

## Expected input

A row-per-placement table (CSV or Excel). Dimensions and metrics may be named differently — map them:

| Role      | Typical columns                                              |
|-----------|-------------------------------------------------------------|
| dimensions| App/URL, Exchange, City, Environment, Video Player Size, Device Type |
| impressions | Impressions (times the ad was shown)                      |
| views     | Complete Views (Video) (times the ad finished)              |

**VTR = Complete Views ÷ Impressions.** It is a *ratio*, so it is only trustworthy when the
impressions denominator is large. Carry impressions next to every VTR you report.

## Workflow

Compute everything from the data (pandas), never estimate. The per-dimension breakdowns are
independent — a sub-agent can run each in parallel; the lead agent then merges them.

1. **Validate & clean.** Coerce impressions/views to numbers; drop or flag rows where views >
   impressions or either is blank, and report how many. State total impressions, total views,
   and the campaign's overall (blended) VTR.
2. **Per-dimension VTR.** For each single dimension (Exchange, Environment, Player Size, Device,
   City, App/URL): VTR and total impressions per value. One sub-agent per dimension.
3. **Combination scan.** Score 2-, 3- and 4-dimension combinations. For every combination output
   **impressions AND VTR together** — never a rate on its own.
4. **Tag by volume.** Label each combination's impressions as High / Medium / Low so the next
   step can tell a real segment from a rounding error.
5. **Two lists.** Candidate winners (high VTR) and candidate losers (high impressions, low VTR).

## Output format

A table of candidate strategies with columns: dimensions in the combo · Impressions · VTR ·
volume tag. Sort so the reader can see both the highest-VTR combos and the highest-volume combos.
Include the campaign's overall VTR and total impressions at the top as the baseline to beat.

## Deliverable

An Excel workbook: an "Overview" sheet (totals + per-dimension VTR) and a "Combinations" sheet
(the full scored list). State the date/row count analyzed at the top.

## Guardrails

- **Never report a VTR without its impressions beside it.** A rate with no denominator is a trap.
- Don't pre-filter to "good" combos here — surface everything with its volume; judgement happens
  in the insight-review step.
- Never fabricate segments or fill blanks with assumptions; report data gaps instead.
