---
name: revise-from-critique
description: >-
  Iterates a deliverable in response to review feedback — prioritizing fixes by severity, rewriting
  only what needs it, and producing a change log. ALWAYS use this whenever the user wants to revise,
  iterate, improve, or produce a "v2" of a document based on critique, reviewer comments, or panel
  feedback, or asks to "apply the feedback" / "address the reviews". Chains naturally after
  critique-panel.
---

# Revise from Critique

Turn a pile of critique into a better draft — deliberately, not by rewriting everything. The goal
is a tighter v2 where every change traces to a real issue, plus a change log so the reviewer can
see their notes were addressed.

## Workflow

1. **Take the original + the prioritized critique.** If you have the panel's consensus-vs-specific
   split, use it — consensus issues are non-negotiable, persona-specific ones are judgement calls.
2. **Triage every issue** into: **Fix** (all Blockers and Consensus items), **Accept** (a good
   persona-specific point worth taking), **Defer / Reject** (out of scope or wrong — say why).
3. **Revise.** Address the Fix and Accept items in the deliverable, keeping it to its original
   length and format. Do not gold-plate — fixing an issue is the job; adding new scope is not.
4. **Re-check the numbers.** Ensure the revision doesn't reintroduce a flaw the critique caught
   (e.g. a rate quoted with no volume, a double-counted total, an over-claim). If the original
   goal was numeric, confirm the v2 still meets it honestly.
5. **Write the change log.** For each issue: what the reviewer said → what changed.

## Output format

1. **Revised deliverable (v2)** — same length/format as the original, issues addressed.
2. **Change log** — issue → change, grouped Fixed / Accepted / Deferred-or-Rejected (with reasons).
3. **Still open** — anything that needs data or a human decision before it can be resolved.

## Guardrails

- **Every change traces to a critique.** No silent rewrites, no new unreviewed claims.
- Don't over-correct: address the issue precisely; resist rewriting things nobody flagged.
- Keep the numbers honest — never "fix" a critique by softening language while leaving a wrong
  figure in place.
- If a reviewer was wrong, it is fine to reject the note — record it in the change log with the
  reason, rather than complying blindly.
