---
name: critique-panel
description: >-
  Runs a panel of distinct, named reviewer personas against a deliverable — each a separate
  sub-agent with its own lens — then compares their critiques to separate consensus issues from
  persona-specific ones. ALWAYS use this whenever the user wants a document, deck, brief, memo,
  analysis or draft reviewed, critiqued, stress-tested, red-teamed, "torn apart", or reviewed
  "as a tough reviewer / EM / partner", or asks for multiple perspectives or to compare critiques.
  Chains naturally onto any produced deliverable.
---

# Critique Panel

One reviewer has blind spots. A panel of sharp, *different* reviewers — run independently so they
don't contaminate each other — lets you compare critiques and find the real issues: the ones every
lens flags. This skill runs that panel and does the comparison.

## The default panel

Four personas, each run as its own sub-agent with a distinct standard. Adapt or swap on request.

1. **The Engagement Manager** — a McKinsey-style EM reviewing a first-year analyst. Cares about
   logic and structure: does the recommendation follow from the evidence? Is it MECE? Is there a
   crisp "so what"? Is the headline the actual answer? Ruthless about hand-waving.
2. **The Client Decision-Maker** — a skeptical CFO/CMO who has to act on this. Cares about: is
   there a clear ask? Does it change a decision? Is the impact quantified? "On how many
   impressions?" is their first question for any claim.
3. **The Data-Quality Skeptic** — checks every number is defensible. Is there volume behind every
   rate? Any double-counting, cherry-picking, small-sample traps, or claims with no figure? If the
   source data is provided, spot-checks the headline claims against it.
4. **The Executive Editor** — can a busy reader get the point in 30 seconds? Does it lead with the
   answer? Jargon, bloat, buried lede, weak title?

## Workflow

1. **Read the deliverable** (and the source data, if given) once, shared to all personas.
2. **Run the panel in parallel.** One sub-agent per persona. Each returns a structured critique:
   - **Top 3 issues**, each with a **severity** (Blocker / Major / Minor) and a **specific fix**,
     quoting or pointing to the exact line — no generic advice.
   - An overall **score out of 5** and a one-line verdict.
3. **Compare the critiques.** Build a comparison that shows, for each issue raised:
   which reviewers flagged it. Split into **Consensus** (2+ reviewers → the real problems, fix
   first) and **Persona-specific** (one lens only → judgement calls).
4. **Prioritize.** A single ranked fix list: all Blockers, then Consensus Majors, then the rest.

## Output format

1. **Panel verdict** — the four scores and one-line verdicts, side by side.
2. **Per-reviewer critique** — each persona's top 3 issues with severity and fix.
3. **Comparison** — the consensus-vs-divergence table. This is the point: what everyone agrees is
   broken is what you fix first.
4. **Prioritized fix list** — ready to hand to the revise step.

## Guardrails

- Every critique must be **specific and tied to the text** (quote the line), never generic.
- Keep the personas genuinely distinct — don't let them converge into the same four notes.
- Be harsh but constructive: each issue names a fix, not just a complaint.
- Separate consensus from one-off opinions honestly — don't inflate a single reviewer's pet peeve
  into a "must fix".
