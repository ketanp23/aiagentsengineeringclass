---
name: sales-analysis-report
# HINT: The description is the TRIGGER, not documentation. Write 2-4 sentences that say
# WHAT this does AND exactly WHEN Claude should reach for it. Be a little "pushy" — name the
# phrases a user would actually type (e.g. "analyze this sales data", "how did we do",
# "revenue trends", "sales report") so it fires even when they don't say the word "report".
description: >-
  TODO — write the trigger description here.
---

# Sales Analysis Report

<!-- HINT: One line on the job this skill does. -->
TODO

## Expected input
<!-- HINT: What file/columns does it expect? List the column ROLES you need (date, revenue,
     region, rep, product, segment, units, returned) and note which are required.
     What should happen if a required column is missing? -->
TODO

## Workflow
<!-- HINT: The ordered steps to run with REAL computation (pandas), not eyeballing.
     Think: 1) validate & clean  2) headline metrics  3) trend  4) region  5) product
     6) rep leaderboard  7) segment & discount. Note which steps can run in PARALLEL
     as sub-agents. Say how returns are handled and how dropped rows are reported. -->
TODO

## Output format
<!-- HINT: The exact sections the report must contain, in order. Lead with an executive
     summary a busy manager reads in 30 seconds. Require every claim to trace to a number. -->
TODO

## Deliverable
<!-- HINT: What file comes out (Excel workbook? Word/PDF?), what chart(s) to include,
     and what to print at the top so the numbers are auditable (date range, row count). -->
TODO

## Guardrails
<!-- HINT: The "never do this" rules — e.g. never invent data, report gaps instead,
     show the date range and row count for reproducibility. -->
TODO
