---
name: board-deck
# HINT: Trigger description. This skill must fire when a report/analysis is being turned into
# slides for SENIOR leadership. Be pushy: tell Claude NOT to build slides directly, and name the
# phrases — "board deck", "for the C-suite / CXO / CEO / CFO", "QBR", "turn this into a deck",
# "format this for the board". Note it chains after a sales/performance report.
description: >-
  TODO — write the trigger description here.
---

# Board Deck (C-Suite)

<!-- HINT: One line — this is a strategic narrative for decision-makers, not an ops readout. -->
TODO

## Audience rules (read first)
<!-- HINT: What do a board and CXOs actually care about, and how does that shape each slide?
     Think: one idea per slide; the TITLE states the conclusion, not the topic; lead with the
     number; ruthless brevity (~30 words/slide); trend not noise; always name the risks. -->
TODO

## Deck structure
<!-- HINT: List the 10-14 slides in order. Suggested spine: Title / Executive summary /
     KPI scorecard (vs prior & vs target) / Performance trend chart / What's driving results /
     Where we're exposed (risks + mitigations) / 2-3 strategic breakdowns / Outlook /
     The ask (decisions needed) / Appendix (methodology, date range, definitions). -->
TODO

## Design standards
<!-- HINT: Consistent template, assertion-evidence layout (headline = point, chart = proof),
     one chart per slide, large legible type, currency in $K/$M on slides. -->
TODO

## Speaker notes
<!-- HINT: Require notes on every content slide — what to say out loud, why it matters, and the
     likely board question with its answer. Nuance lives here, not on the slide face. -->
TODO

## Deliverable
<!-- HINT: A .pptx built with the PowerPoint capability, real charts from the data. What must
     you ASK for up front (company, meeting date/period, the specific "ask")? If chaining from a
     report, reuse its numbers/charts instead of recomputing. -->
TODO

## Guardrails
<!-- HINT: Never fabricate metrics/targets/forecasts; omit or ask instead. Keep operational
     detail in the appendix. Every headline claim tied to a figure from the source. -->
TODO
