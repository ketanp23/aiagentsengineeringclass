---
name: critique-panel
# HINT: Trigger description. Fire whenever the user wants a deliverable reviewed / critiqued /
# stress-tested / "torn apart" / reviewed "as a tough EM or partner", or wants multiple
# perspectives or to compare critiques. Be pushy. Note it chains onto any produced deliverable.
description: >-
  TODO — write the trigger description here.
---

# Critique Panel

<!-- HINT: One line on the core idea — one reviewer has blind spots; a panel of DIFFERENT reviewers
     run independently lets you compare critiques and find the issues everyone flags. -->
TODO

## The default panel
<!-- HINT: Define ~4 distinct reviewer personas, each run as its own sub-agent. Suggested lenses:
     the Engagement Manager (McKinsey EM — logic, structure, MECE, so-what, is the headline the
     answer); the Client Decision-Maker (CFO/CMO — is there a clear ask? quantified? "on how many
     impressions?"); the Data-Quality Skeptic (volume behind every rate? double-counting? traps?
     verify vs source if given); the Executive Editor (30-second read? leads with the answer?
     jargon/bloat/buried lede). Keep them genuinely different. -->
TODO

## Workflow
<!-- HINT: 1) read the deliverable (+ source data if given), shared to all  2) run personas in
     PARALLEL as sub-agents — each returns top-3 issues with SEVERITY (Blocker/Major/Minor) and a
     SPECIFIC fix quoting the line, plus a score /5  3) COMPARE — which reviewers flagged each
     issue; split Consensus (2+ = fix first) vs Persona-specific  4) one prioritized fix list. -->
TODO

## Output format
<!-- HINT: Panel verdict (scores side by side) · per-reviewer critique · the consensus-vs-divergence
     comparison (the point) · a prioritized fix list ready for the revise step. -->
TODO

## Guardrails
<!-- HINT: Critiques must be specific and tied to the text (quote the line), not generic. Keep
     personas distinct. Harsh but constructive — every issue names a fix. Don't inflate one
     reviewer's pet peeve into a consensus must-fix. -->
TODO
