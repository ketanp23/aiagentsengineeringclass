---
name: revise-from-critique
# HINT: Trigger description. Fire whenever the user wants to revise / iterate / improve / make a
# "v2" from critique or reviewer comments, or "apply the feedback" / "address the reviews".
# Be pushy. Note it chains after critique-panel.
description: >-
  TODO — write the trigger description here.
---

# Revise from Critique

<!-- HINT: One line — turn critique into a better draft deliberately, not by rewriting everything;
     every change traces to a real issue, plus a change log. -->
TODO

## Workflow
<!-- HINT: 1) take original + prioritized critique (use consensus-vs-specific split if present)
     2) triage each issue: Fix (blockers + consensus) / Accept (good persona-specific point) /
     Defer-or-Reject (say why)  3) revise — address Fix + Accept, keep original length/format,
     don't gold-plate  4) re-check numbers so you don't reintroduce a caught flaw; confirm any
     numeric goal is still met honestly  5) write the change log (issue → what changed). -->
TODO

## Output format
<!-- HINT: Revised deliverable (v2, same length/format) · change log grouped Fixed / Accepted /
     Deferred-or-Rejected with reasons · "still open" items needing data or a human decision. -->
TODO

## Guardrails
<!-- HINT: Every change traces to a critique — no silent rewrites. Don't over-correct. Keep numbers
     honest (don't soften language over a wrong figure). It's OK to reject a wrong note — log why. -->
TODO
